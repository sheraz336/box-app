
class AuthModel {
  String email = '';
  String password = '';

}

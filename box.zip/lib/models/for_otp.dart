class OTPModel {
  String email;
  String otp;

  OTPModel({required this.email, required this.otp});
}

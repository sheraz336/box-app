class VerificationModel {
  String countryCode;
  String phoneNumber;

  VerificationModel({
    this.countryCode = "+92",
    this.phoneNumber = '',
  });
}
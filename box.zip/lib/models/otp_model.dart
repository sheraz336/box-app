class OtpModel {
  String otp;
  String phoneNumber;

  OtpModel({
    required this.otp,
    required this.phoneNumber,
  });
}

class SignUpModel {
  bool isSignUpCompleted;

  SignUpModel({
    required this.isSignUpCompleted,
  });
}